/*
 * Image editor
 * Noora Toimela 2017
 * TIEVA31 Principles of Programming Graphical User Interfaces 
 * 
 */
package ProjectWorkPackage;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;
import javax.swing.border.Border;

/**
 *
 * @author Noora
 */
public class Painting extends JPanel{
    //Image variables
    BufferedImage i;   
    int w;
    int h;
    int ow;
    int oh;
    int rotation;
    
    //Caption variables
    String c;
    Color cColor;
    String size;
    String style;
    String place;

    //Border variable
    Border line;
    
    //Flags for edit-events
    boolean rotationDone;
    boolean captionDone;
    boolean bordersDone;
    
    public void setImage(BufferedImage i, int w, int h) {
        this.i = i;
        this.w = w;
        this.h = h;       
    }   

    public void setOriginalSize(int ow, int oh) {
        this.ow = ow;
        this.oh = oh;
    }   

    public void setCaption(String c, String place, String style, 
        String size, Color cColor, boolean captionDone) {
        this.c = c;
        this.place = place;
        this.style = style;
        this.size = size;
        this.cColor = cColor;
        this.captionDone = captionDone;
    }
    
    public void setRotation(int rotation, boolean rotationDone) {
        this.rotation = rotation;
        this.rotationDone = rotationDone;
    }
    
    public void setBorders(Border line, boolean bordersDone) {
        this.line = line;
        this.bordersDone = bordersDone;
    }
    
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 =(Graphics2D)g.create();
         
        //If there is an image set
        if(this.i != null) {
            //If image is rotated
            if(rotationDone) {
                //Rotating and scaling
                g2.rotate(Math.toRadians(rotation), w/2, h/2);
                AffineTransform imageAdjust = AffineTransform.getScaleInstance((float)getWidth()/ow, (float)getHeight()/oh);
                
                //Translation variables
                int a = (w-h)/2;
                int b = (h-w)/2;
                
                if(rotation == 90 || rotation == 270) {
                    g2.translate(a, b);
                }
                
                g2.drawImage(this.i, imageAdjust, this);
                
                //Translations and rotation is set back to original
                if(rotation == 90 || rotation == 270) {
                    g2.translate(-a, -b);
                }
                g2.rotate(Math.toRadians(-rotation), w/2, h/2);
                
            }
            else {
                AffineTransform imageAdjust = AffineTransform.getScaleInstance((float)getWidth()/i.getWidth(this), (float)getHeight()/i.getHeight(this));
                g2.drawImage(this.i, imageAdjust, this);
            }  
            
            //If caption is added
            if(captionDone) {               
                g2.setFont(new Font(style, Font.PLAIN, Integer.parseInt(size)));
                g2.setColor(cColor);
                
                if(place.equals("Top") || place.equals("Ylös")) {
                    g2.drawString(c, w/8, w/8);
                }
                else if(place.equals("Bottom") || place.equals("Alas")) {
                    g2.drawString(c, w/8, h-h/8);
                }                  
            }  
            
            //If borders are added
            if(bordersDone) {
                line.paintBorder(this, g2, 0, 0, w, h);
            }   
        }         
    } 
}
